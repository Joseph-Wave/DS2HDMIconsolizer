#include <nds.h>
#include <stdio.h>

#define  SPRITE_MAX 16

OamState *oam = &oamSub;

typedef struct {
	int x,y;
	u16* gfx;
} mySprite;

mySprite sprites[SPRITE_MAX];

// 16 sprites of 64*64 to fill the 256*192 px screen

int coord_x[] = {0*64,1*64,2*64,3*64,   0*64,1*64,2*64,3*64,   0*64,1*64,2*64,3*64,   0*64,1*64,2*64,3*64,};
int coord_y[] = {0*64,0*64,0*64,0*64,   1*64,1*64,1*64,1*64,   2*64,2*64,2*64,2*64,   3*64,3*64,3*64,3*64,};

void createSprite (mySprite* s, int x, int y) {
	s->x = x;
	s->y = y;
	s->gfx = oamAllocateGfx(oam, SpriteSize_64x64, SpriteColorFormat_256Color);
}

void fillSprite(mySprite* s) {
	static int x_cov = 0;
	createSprite(s, coord_x[x_cov], coord_y[x_cov]);
	if (++x_cov >= SPRITE_MAX) x_cov = 0;		
	u8 c = 255;
	u16 color = c | (c << 8);
	swiCopy(&color, s->gfx, ((SpriteSize_64x64 & 0xFFF) << 4) | COPY_MODE_FILL);
}

void createSprites (void) {
	for(int i = 0; i < SPRITE_MAX; i++) fillSprite(&sprites[i]);
}

void updateSprites (void) {
	for(int i = 0; i < SPRITE_MAX; i++) {
		oamSet( // void oamSet(OamState* oam, int id,  int x, int y, int priority, int palette_alpha, SpriteSize size, SpriteColorFormat format, const void* gfxOffset, int affineIndex, bool sizeDouble, bool hide);
			oam, i, sprites[i].x, sprites[i].y, 0, 0,
			SpriteSize_64x64, SpriteColorFormat_256Color, 
			sprites[i].gfx, -1, false, false, false, false, false);
	}
}

 // [0,31]
static int color_r = 4;
static int color_g = 31;
static int color_b = 16;

void color_fillScreen () {
	for(int i = 0; i < 256; i++) SPRITE_PALETTE_SUB[i] = RGB15(color_r, color_g, color_b);
}

int main(void)  {

	videoSetMode(MODE_0_2D);
	videoSetModeSub(MODE_0_2D);
	vramSetBankD(VRAM_D_SUB_SPRITE);
	oamInit(oam, SpriteMapping_1D_128, false);

	createSprites();

	color_fillScreen();

	PrintConsole topScreen;

	vramSetBankA(VRAM_A_MAIN_BG);
	vramSetBankC(VRAM_C_SUB_BG);

	consoleInit(&topScreen, 3,BgType_Text4bpp, BgSize_T_256x256, 31, 0, true, true);

	consoleSelect(&topScreen);

	iprintf("\n\n\tRGB555 v1.0\n");

	bool main_scr = false;

	while(1) { 

		scanKeys();
		int keys = keysDown();
		
		if(keys & KEY_Y) {
			if (++color_r >= 32) color_r = 0;
			color_fillScreen();
		}

		if(keys & KEY_B) {
			if (++color_g >= 32) color_g = 0;
			color_fillScreen();
		}

		if(keys & KEY_A) {
			if (++color_b >= 32) color_b = 0;
			color_fillScreen();
		}
		
		if(keys & KEY_START) {
			main_scr = !main_scr;
			if (main_scr) lcdMainOnBottom();
			else lcdMainOnTop();
		}

		iprintf("\x1b[16;0H RGB =                \n");
		iprintf("\x1b[16;0H RGB = %d, %d, %d\n", color_r, color_g, color_b);

		updateSprites();
		swiWaitForVBlank();
		oamUpdate(oam);

	}

	return 0;
}
