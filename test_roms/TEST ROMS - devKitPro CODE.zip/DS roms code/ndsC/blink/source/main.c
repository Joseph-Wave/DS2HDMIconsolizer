#include <nds.h>
#include <stdio.h>

volatile int colorDelay = 0;

void Vblank() {
		
	bool colorSwitch = ++colorDelay % 60 > 30;
	
	int color_r = colorSwitch ? 16 : 8;
	int color_g = colorSwitch ? 31 : 4;
	int color_b = colorSwitch ? 4 : 31;
	
	for(int i = 0; i < 256; i++) SPRITE_PALETTE_SUB[i] = RGB15(color_r,color_g,color_b);
}

#define SPRITE_MAX 16

OamState *oam = &oamSub;

typedef struct {
	int x,y;
	u16* gfx;
} mySprite;

mySprite sprites[SPRITE_MAX];

// 256 x 192 px
int coord_x[] = {0*64,1*64,2*64,3*64,   0*64,1*64,2*64,3*64,   0*64,1*64,2*64,3*64,   0*64,1*64,2*64,3*64,};
int coord_y[] = {0*64,0*64,0*64,0*64,   1*64,1*64,1*64,1*64,   2*64,2*64,2*64,2*64,   3*64,3*64,3*64,3*64,};

void updateSprites(void) {
	for(int i = 0; i < SPRITE_MAX; i++) {
		//an api function: void oamSet(OamState* oam, int id,  int x, int y, int priority, int palette_alpha, SpriteSize size, SpriteColorFormat format, const void* gfxOffset, int affineIndex, bool sizeDouble, bool hide);
		oamSet(oam, 
			i, 
			sprites[i].x, sprites[i].y, 
			0, 
			0,
			SpriteSize_64x64,
			SpriteColorFormat_256Color, 
			sprites[i].gfx, 
			-1, 
			false, 
			false,
			false,
			false, 
			false);
	}
}

int x_cov = 0;

void createSprite(mySprite* s, int x, int y) {
	s->x = x;
	s->y = y;
	s->gfx = oamAllocateGfx(oam, SpriteSize_64x64, SpriteColorFormat_256Color);
}

void randomSprite(mySprite* s) {
	createSprite(s, coord_x[x_cov], coord_y[x_cov]);
	if (++x_cov >= SPRITE_MAX) x_cov = 0;
	u8 c = 255;
	u16 color = c | (c << 8);
	swiCopy(&color, s->gfx, ((SpriteSize_64x64 & 0xFFF) << 4) | COPY_MODE_FILL);
}

int main(void)  {
	
	irqSet(IRQ_VBLANK, Vblank);

	videoSetMode(MODE_0_2D);
	videoSetModeSub(MODE_0_2D);
	vramSetBankD(VRAM_D_SUB_SPRITE);

	oamInit(oam, SpriteMapping_1D_128, false);

	for(int i = 0; i < SPRITE_MAX; i++) randomSprite(&sprites[i]);
	for(int i = 0; i < 256; i++) SPRITE_PALETTE_SUB[i] = RGB15(31,31,31);
	
	//lcdMainOnTop();
	lcdMainOnBottom();
	
	bool main_scr = false;

	while(1) { 

		
		
		scanKeys();
		int keys = keysDown();
		
		if(keys & KEY_START) {
			main_scr = !main_scr;
			if (main_scr) lcdMainOnBottom();
			else lcdMainOnTop();
		}

		updateSprites();
		swiWaitForVBlank();
		oamUpdate(oam);
	}

	return 0;
}
